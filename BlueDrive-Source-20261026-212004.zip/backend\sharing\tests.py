import base64
import os

from django.contrib.auth.models import User
from django.core.files.base import ContentFile
from django.test import TestCase, override_settings
from django.urls import reverse

from accounts.models import Membership, Tenant
from files.models import File
from folders.models import Folder
from security.aes_service import (
    build_file_aad,
    encrypt_bytes,
    generate_dek,
    get_master_key,
    wrap_dek,
)

from .models import Share


@override_settings(NEXTJS_FRONTEND_URL="http://127.0.0.1:3000")
class SharingAccessTests(TestCase):
    def setUp(self):
        os.environ["SECUREDRIVE_AES_KEY"] = base64.b64encode(
            os.urandom(32)
        ).decode()

        self.user_a = User.objects.create_user(
            username="user_a",
            password="TestPass123!",
        )
        self.user_b = User.objects.create_user(
            username="user_b",
            password="TestPass123!",
        )

        self.folder_a = Folder.objects.create(
            tenant=self.user_a.personal_tenant,
            owner=self.user_a,
            folder_name="Shared Folder",
        )

        self.file_a = self._create_encrypted_file(
            owner=self.user_a,
            folder=self.folder_a,
            name="secret.txt",
            plaintext=b"secret content",
            mime_type="text/plain",
        )

    def _create_encrypted_file(
        self,
        *,
        owner,
        folder,
        name,
        plaintext,
        mime_type,
    ):
        drive_file = File.objects.create(
            tenant=folder.tenant,
            owner=owner,
            folder=folder,
            file_name=name,
            file_size=len(plaintext),
            mime_type=mime_type,
            hash_sha256="",
            is_encrypted=True,
            encryption_version=1,
        )

        aad = build_file_aad(
            owner_id=owner.id,
            file_id=drive_file.id,
            version=drive_file.encryption_version,
        )
        dek = generate_dek()
        ciphertext, nonce = encrypt_bytes(
            plaintext,
            dek,
            aad,
        )
        wrapped_dek, dek_nonce = wrap_dek(
            dek,
            get_master_key(),
        )

        drive_file.file_path.save(
            f"tests-{drive_file.id}.enc",
            ContentFile(ciphertext),
            save=False,
        )
        drive_file.encryption_nonce = nonce
        drive_file.wrapped_dek = wrapped_dek
        drive_file.dek_nonce = dek_nonce
        drive_file.save(
            update_fields=[
                "file_path",
                "encryption_nonce",
                "wrapped_dek",
                "dek_nonce",
                "updated_at",
            ]
        )
        return drive_file

    def _share_file(self, recipient=None):
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_file", args=[self.file_a.id]),
            {"username": recipient or self.user_b.username},
        )
        self.assertEqual(response.status_code, 302)
        return Share.objects.get(
            file=self.file_a,
            receiver=self.user_b,
        )

    def test_api_repeated_share_is_noop_and_logs_once(self):
        import json
        from accounts.access import get_default_workspace
        from logs.models import ActivityLog

        self.user_b.email = "repeat-recipient@example.test"
        self.user_b.save(update_fields=["email"])
        workspace = get_default_workspace(self.file_a.tenant)
        self.folder_a.workspace = workspace
        self.folder_a.save(update_fields=["workspace"])
        self.file_a.workspace = workspace
        self.file_a.save(update_fields=["workspace"])

        self.client.force_login(self.user_a)
        url = reverse("drive_items_share_api")
        payload = json.dumps({
            "file_ids": [self.file_a.pk], "folder_ids": [],
            "email": self.user_b.email, "permission": Share.Permission.VIEWER,
        })
        first = self.client.post(url, payload, content_type="application/json")
        second = self.client.post(url, payload, content_type="application/json")
        self.assertEqual(first.status_code, 200)
        self.assertEqual(first.json()["count"], 1)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(second.json()["count"], 0)
        logs = ActivityLog.objects.filter(user=self.user_a, action=ActivityLog.Action.SHARE)
        self.assertEqual(logs.count(), 1)
        self.assertEqual(logs.first().metadata["operation"], "created")
        self.assertEqual(logs.first().metadata["resource_changes"][0]["name"], self.file_a.file_name)

    def test_repeating_identical_file_share_does_not_duplicate_audit(self):
        from logs.models import ActivityLog

        self.client.force_login(self.user_a)
        path = reverse("share_file", args=[self.file_a.id])
        payload = {"username": self.user_b.username, "permission": Share.Permission.VIEWER}
        self.assertEqual(self.client.post(path, payload).status_code, 302)
        self.assertEqual(self.client.post(path, payload).status_code, 302)

        history = ActivityLog.objects.filter(
            user=self.user_a, action=ActivityLog.Action.SHARE, object_id=self.file_a.pk,
        )
        self.assertEqual(history.count(), 1)
        self.assertEqual(history.first().metadata["operation"], "created")
        self.assertEqual(Share.objects.filter(file=self.file_a, receiver=self.user_b).count(), 1)

    def test_changed_share_permission_is_distinct_and_attributed(self):
        from logs.models import ActivityLog

        self.client.force_login(self.user_a)
        path = reverse("share_file", args=[self.file_a.id])
        self.client.post(path, {"username": self.user_b.username, "permission": Share.Permission.VIEWER})
        self.client.post(path, {"username": self.user_b.username, "permission": Share.Permission.EDITOR})
        history = list(ActivityLog.objects.filter(
            user=self.user_a, action=ActivityLog.Action.SHARE, object_id=self.file_a.pk,
        ).order_by("created_at", "pk"))
        self.assertEqual(len(history), 2)
        self.assertEqual([row.metadata["operation"] for row in history], ["created", "permission_changed"])
        self.assertEqual(history[1].metadata["previous_permission"], Share.Permission.VIEWER)
        self.assertEqual(history[1].tenant_id, self.file_a.tenant_id)
        self.assertEqual(history[1].metadata["recipient_username"], self.user_b.username)

    def test_revoke_share_log_contains_resource_and_recipient(self):
        from logs.models import ActivityLog

        share = self._share_file()
        self.client.force_login(self.user_a)
        self.client.post(reverse("revoke_share", args=[share.pk]))
        event = ActivityLog.objects.get(user=self.user_a, action=ActivityLog.Action.REVOKE_SHARE)
        self.assertEqual(event.object_id, self.file_a.pk)
        self.assertEqual(event.tenant_id, self.file_a.tenant_id)
        self.assertEqual(event.metadata["operation"], "revoked")
        self.assertEqual(event.metadata["resource_names"], [self.file_a.file_name])

    def test_shared_file_can_view_and_download(self):
        share = self._share_file()

        self.client.force_login(self.user_b)

        view_response = self.client.get(
            reverse("file_view", args=[self.file_a.id])
        )
        self.assertEqual(view_response.status_code, 200)
        self.assertEqual(
            b"".join(view_response.streaming_content),
            b"secret content",
        )

        download_response = self.client.get(
            reverse("file_download", args=[self.file_a.id])
        )
        self.assertEqual(download_response.status_code, 200)
        self.assertIn(
            'attachment; filename="secret.txt"',
            download_response["Content-Disposition"],
        )
        self.assertTrue(Share.objects.filter(id=share.id).exists())

    def test_editor_can_rename_shared_file(self):
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_file", args=[self.file_a.id]),
            {"username": self.user_b.username, "permission": Share.Permission.EDITOR},
        )
        self.assertEqual(response.status_code, 302)
        share = Share.objects.get(file=self.file_a, receiver=self.user_b)
        self.assertEqual(share.permission, Share.Permission.EDITOR)

        self.client.force_login(self.user_b)
        response = self.client.post(
            reverse("file_rename", args=[self.file_a.id]),
            {"file_name": "renamed.txt"},
        )
        self.assertEqual(response.status_code, 302)
        self.file_a.refresh_from_db()
        self.assertEqual(self.file_a.file_name, "renamed.txt")

    def test_viewer_cannot_rename_shared_file(self):
        self._share_file()
        self.client.force_login(self.user_b)
        response = self.client.post(
            reverse("file_rename", args=[self.file_a.id]),
            {"file_name": "renamed.txt"},
        )
        self.assertEqual(response.status_code, 302)
        self.file_a.refresh_from_db()
        self.assertEqual(self.file_a.file_name, "secret.txt")

    def test_share_accepts_email_address(self):
        self.user_b.email = "receiver@example.com"
        self.user_b.save(update_fields=["email"])

        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_file", args=[self.file_a.id]),
            {"username": "RECEIVER@example.com"},
        )
        self.assertEqual(response.status_code, 302)
        self.assertTrue(
            Share.objects.filter(
                file=self.file_a, receiver=self.user_b
            ).exists()
        )

    def test_owner_can_revoke_share(self):
        share = self._share_file()

        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("revoke_share", args=[share.id])
        )
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Share.objects.filter(id=share.id).exists())

    def test_receiver_cannot_revoke_share(self):
        share = self._share_file()

        self.client.force_login(self.user_b)
        response = self.client.post(
            reverse("revoke_share", args=[share.id])
        )
        self.assertEqual(response.status_code, 404)
        self.assertTrue(Share.objects.filter(id=share.id).exists())

    def test_search_redirects_to_nextjs_preserving_query(self):
        self.file_a.deleted_at = "2026-08-01T00:00:00Z"
        self.file_a.save(update_fields=["deleted_at"])

        self.folder_a.deleted_at = "2026-08-01T00:00:00Z"
        self.folder_a.save(update_fields=["deleted_at"])

        self.client.force_login(self.user_a)

        response = self.client.get(
            reverse("search"),
            {"q": "secret"},
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(
            response["Location"],
            "http://127.0.0.1:3000/drive?q=secret",
        )

        response = self.client.get(
            reverse("search"),
            {"q": "Shared Folder"},
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(
            response["Location"],
            "http://127.0.0.1:3000/drive?q=Shared+Folder",
        )

    def test_other_user_cannot_open_private_folder_or_file(self):
        self.client.force_login(self.user_b)

        response = self.client.get(
            reverse("folder_open", args=[self.folder_a.id])
        )
        self.assertEqual(response.status_code, 404)

    def test_suspended_business_member_cannot_access_owned_tenant_files(self):
        business = Tenant.objects.create(
            kind=Tenant.Kind.BUSINESS,
            name="Suspended Workspace",
        )
        membership = Membership.objects.create(
            tenant=business,
            user=self.user_a,
            role=Membership.Role.MEMBER,
        )
        folder = Folder.objects.create(
            tenant=business,
            owner=self.user_a,
            folder_name="Business folder",
        )
        drive_file = File.objects.create(
            tenant=business,
            owner=self.user_a,
            folder=folder,
            file_name="business.txt",
            file_size=0,
            mime_type="text/plain",
            is_encrypted=False,
        )
        membership.status = Membership.Status.SUSPENDED
        membership.save(update_fields=["status", "updated_at"])

        self.client.force_login(self.user_a)
        response = self.client.get(reverse("file_details", args=[drive_file.id]))
        self.assertEqual(response.status_code, 404)

        response = self.client.post(
            reverse("file_move_to_trash", args=[drive_file.id])
        )
        self.assertEqual(response.status_code, 404)
        drive_file.refresh_from_db()
        self.assertIsNone(drive_file.deleted_at)

    def test_suspended_member_does_not_keep_access_through_an_existing_share(self):
        Membership.objects.create(
            tenant=self.user_a.personal_tenant,
            user=self.user_b,
            role=Membership.Role.MEMBER,
            status=Membership.Status.SUSPENDED,
        )
        share = Share.objects.create(
            tenant=self.user_a.personal_tenant,
            file=self.file_a,
            owner=self.user_a,
            receiver=self.user_b,
            permission=Share.Permission.VIEWER,
        )

        self.client.force_login(self.user_b)

        response = self.client.get(reverse("file_details", args=[self.file_a.id]))

        self.assertEqual(response.status_code, 404)
        self.assertTrue(Share.objects.filter(pk=share.pk).exists())

    def test_active_member_of_another_business_tenant_cannot_access_resource_by_id(self):
        owner_tenant = Tenant.objects.create(
            kind=Tenant.Kind.BUSINESS,
            name="Owner Workspace",
        )
        Membership.objects.create(
            tenant=owner_tenant,
            user=self.user_a,
            role=Membership.Role.ADMIN,
        )
        other_tenant = Tenant.objects.create(
            kind=Tenant.Kind.BUSINESS,
            name="Other Workspace",
        )
        Membership.objects.create(
            tenant=other_tenant,
            user=self.user_b,
            role=Membership.Role.MEMBER,
        )
        drive_file = File.objects.create(
            tenant=owner_tenant,
            owner=self.user_a,
            file_name="tenant-private.txt",
            file_size=0,
            mime_type="text/plain",
            is_encrypted=False,
        )

        self.client.force_login(self.user_b)

        for route in ("file_details", "file_download", "file_view"):
            with self.subTest(route=route):
                response = self.client.get(reverse(route, args=[drive_file.id]))
                self.assertEqual(response.status_code, 404)

        response = self.client.post(
            reverse("file_rename", args=[drive_file.id]),
            {"file_name": "renamed.txt"},
        )
        self.assertEqual(response.status_code, 302)
        response = self.client.post(
            reverse("file_move_to_trash", args=[drive_file.id])
        )
        self.assertEqual(response.status_code, 404)
        response = self.client.post(
            reverse("share_file", args=[drive_file.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 404)
        drive_file.refresh_from_db()
        self.assertEqual(drive_file.file_name, "tenant-private.txt")
        self.assertIsNone(drive_file.deleted_at)
        self.assertFalse(Share.objects.filter(file=drive_file).exists())

    def test_platform_staff_does_not_bypass_file_permissions(self):
        # Django staff alone is not a dedicated Platform Admin identity.
        # Without an active tenant membership, active_tenant_required returns
        # HTTP 403 before per-file authorization can return HTTP 404.
        platform_staff = User.objects.create_user(
            username="staff_without_tenant",
            is_staff=True,
        )
        self.client.force_login(platform_staff)

        for route in ("file_view", "file_download", "file_details"):
            with self.subTest(route=route):
                response = self.client.get(reverse(route, args=[self.file_a.id]))
                self.assertEqual(response.status_code, 403)

        response = self.client.post(
            reverse("file_rename", args=[self.file_a.id]),
            {"file_name": "unauthorized.txt"},
        )
        self.assertEqual(response.status_code, 403)
        self.file_a.refresh_from_db()
        self.assertEqual(self.file_a.file_name, "secret.txt")

        response = self.client.post(reverse("file_move_to_trash", args=[self.file_a.id]))
        self.assertEqual(response.status_code, 403)
        self.file_a.refresh_from_db()
        self.assertIsNone(self.file_a.deleted_at)

        response = self.client.post(
            reverse("share_file", args=[self.file_a.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 403)
        self.assertFalse(Share.objects.filter(file=self.file_a).exists())

    def test_active_platform_admin_is_blocked_from_drive_endpoints(self):
        # A dedicated administrator is also blocked by the Platform Admin
        # middleware, independently of file-owner or workspace permissions.
        from accounts.models import PlatformAdminIdentity

        super_admin = User.objects.create_superuser(
            username="admin_inviter", email="inviter@example.test",
            password="TestPass123!",
        )
        dedicated_admin = User.objects.create_user(
            username="dedicated_admin", is_staff=True,
        )
        PlatformAdminIdentity.objects.create(
            user=dedicated_admin,
            invited_by=super_admin,
            status=PlatformAdminIdentity.Status.ACTIVE,
        )
        self.client.force_login(dedicated_admin)

        for route in ("file_view", "file_download", "file_details"):
            with self.subTest(route=route):
                response = self.client.get(reverse(route, args=[self.file_a.id]))
                self.assertEqual(response.status_code, 403)

        for route, data in (
            ("file_rename", {"file_name": "unauthorized.txt"}),
            ("file_move_to_trash", {}),
            ("share_file", {"username": self.user_b.username}),
        ):
            with self.subTest(route=route):
                response = self.client.post(reverse(route, args=[self.file_a.id]), data)
                self.assertEqual(response.status_code, 403)

        self.file_a.refresh_from_db()
        self.assertEqual(self.file_a.file_name, "secret.txt")
        self.assertIsNone(self.file_a.deleted_at)
        self.assertFalse(Share.objects.filter(file=self.file_a).exists())


@override_settings(NEXTJS_FRONTEND_URL="http://127.0.0.1:3000")
class SharingFolderTests(TestCase):
    def setUp(self):
        self.user_a = User.objects.create_user(
            username="folder_owner",
            password="TestPass123!",
        )
        self.user_b = User.objects.create_user(
            username="folder_receiver",
            password="TestPass123!",
        )
        self.folder = Folder.objects.create(
            tenant=self.user_a.personal_tenant,
            owner=self.user_a,
            folder_name="Project",
        )
        self.child = Folder.objects.create(
            tenant=self.folder.tenant,
            owner=self.user_a,
            folder_name="Documents",
            parent=self.folder,
        )

    def test_folder_share_becomes_unavailable_after_soft_delete(self):
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder.id]),
            {
                "username": self.user_b.username,
            },
        )
        self.assertEqual(response.status_code, 302)

        self.folder.deleted_at = "2026-08-01T00:00:00Z"
        self.folder.save(update_fields=["deleted_at"])

        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("folder_open", args=[self.folder.id])
        )
        self.assertEqual(response.status_code, 404)
        self.assertTrue(Share.objects.filter(folder=self.folder, receiver=self.user_b).exists())

    def test_shared_folder_details_becomes_unavailable_after_soft_delete(self):
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 302)

        self.folder.deleted_at = "2026-08-01T00:00:00Z"
        self.folder.save(update_fields=["deleted_at"])

        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("folder_details", args=[self.folder.id])
        )
        self.assertEqual(response.status_code, 404)

    def test_shared_folder_details_excludes_deleted_descendants(self):
        self.child.deleted_at = "2026-08-01T00:00:00Z"
        self.child.save(update_fields=["deleted_at"])

        deleted_child = Folder.objects.create(
            tenant=self.folder.tenant,
            owner=self.user_a,
            folder_name="Deleted child",
            parent=self.folder,
            deleted_at="2026-08-01T00:00:00Z",
        )

        File.objects.create(
            tenant=self.folder.tenant,
            owner=self.user_a,
            folder=self.folder,
            file_name="active.txt",
        )

        File.objects.create(
            tenant=self.folder.tenant,
            owner=self.user_a,
            folder=deleted_child,
            file_name="deleted.txt",
            deleted_at="2026-08-01T00:00:00Z",
        )

        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 302)

        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("folder_details", args=[self.folder.id])
        )

        self.assertEqual(response.status_code, 200)

        payload = response.json()

        self.assertEqual(payload["folder_count"], 0)
        self.assertEqual(payload["file_count"], 1)
        self.assertEqual(payload["location"], "Shared with me")
        self.assertEqual(payload["access"], "Viewer")
        self.assertEqual(payload["shared_by"], self.user_a.username)

    def test_inherited_share_allows_child_folder_details(self):
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 302)

        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("folder_details", args=[self.child.id])
        )
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertEqual(payload["name"], "Documents")
        self.assertEqual(payload["access"], "Viewer")
        self.assertEqual(payload["shared_by"], self.user_a.username)

    def test_direct_child_share_survives_parent_share_revoke(self):
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 302)
        parent_share = Share.objects.get(
            folder=self.folder,
            receiver=self.user_b,
        )

        response = self.client.post(
            reverse("share_folder", args=[self.child.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 302)
        child_share = Share.objects.get(
            folder=self.child,
            receiver=self.user_b,
        )

        response = self.client.post(
            reverse("revoke_share", args=[parent_share.id])
        )
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Share.objects.filter(id=parent_share.id).exists())
        self.assertTrue(Share.objects.filter(id=child_share.id).exists())

        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("folder_open", args=[self.child.id])
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(
            response["Location"],
            f"http://127.0.0.1:3000/drive?folder={self.child.id}",
        )

    def test_shared_child_file_details_exposes_shared_location_only(self):
        child_file = File.objects.create(
            tenant=self.folder.tenant,
            owner=self.user_a,
            folder=self.child,
            file_name="child.txt",
        )
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder.id]),
            {"username": self.user_b.username},
        )
        self.assertEqual(response.status_code, 302)

        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("file_details", args=[child_file.id])
        )
        self.assertEqual(response.status_code, 200)
        payload = response.json()
        self.assertEqual(payload["location"], "Shared with me / Documents")
        self.assertEqual(payload["access"], "Viewer")
        self.assertEqual(payload["shared_by"], self.user_a.username)

    def test_deleted_shared_file_becomes_unavailable(self):
        # Reuse the file fixture from SharingAccessTests semantics with a simple DB object.
        file_obj = File.objects.create(
            tenant=self.folder.tenant,
            owner=self.user_a,
            folder=self.folder,
            file_name="deleted.txt",
            deleted_at="2026-08-01T00:00:00Z",
        )
        Share.objects.create(
            tenant=self.folder.tenant,
            owner=self.user_a,
            receiver=self.user_b,
            file=file_obj,
        )

        self.client.force_login(self.user_b)
        response = self.client.get(reverse("file_view", args=[file_obj.id]))
        self.assertEqual(response.status_code, 404)

        response = self.client.get(reverse("file_download", args=[file_obj.id]))
        self.assertEqual(response.status_code, 404)

    def test_permanent_delete_removes_share_target(self):
        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder.id]),
            {
                "username": self.user_b.username,
            },
        )
        self.assertEqual(response.status_code, 302)

        share = Share.objects.get(
            folder=self.folder,
            receiver=self.user_b,
        )

        self.folder.delete()

        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("folder_open", args=[share.folder_id])
        )
        self.assertEqual(response.status_code, 404)
        self.assertFalse(
            Share.objects.filter(id=share.id).exists()
        )


class AuthorizationIDORTests(TestCase):
    def setUp(self):
        self.user_a = User.objects.create_user(
            username="idor_a",
            password="TestPass123!",
        )
        self.user_b = User.objects.create_user(
            username="idor_b",
            password="TestPass123!",
        )
        self.folder_a = Folder.objects.create(
            tenant=self.user_a.personal_tenant,
            owner=self.user_a,
            folder_name="Private",
        )
        self.file_a = File.objects.create(
            tenant=self.folder_a.tenant,
            owner=self.user_a,
            folder=self.folder_a,
            file_name="secret.txt",
        )

    def test_other_user_cannot_open_private_folder(self):
        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("folder_open", args=[self.folder_a.id])
        )
        self.assertEqual(response.status_code, 404)

    def test_other_user_cannot_download_private_file(self):
        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("file_download", args=[self.file_a.id])
        )
        self.assertEqual(response.status_code, 404)

    def test_other_user_cannot_view_private_file(self):
        self.client.force_login(self.user_b)
        response = self.client.get(
            reverse("file_view", args=[self.file_a.id])
        )
        self.assertEqual(response.status_code, 404)

    def test_other_user_cannot_delete_private_file(self):
        self.client.force_login(self.user_b)
        response = self.client.post(
            reverse("file_move_to_trash", args=[self.file_a.id])
        )
        self.assertEqual(response.status_code, 404)
        self.file_a.refresh_from_db()
        self.assertIsNone(self.file_a.deleted_at)

    def test_trashed_folder_cannot_be_shared_as_new_share(self):
        self.folder_a.deleted_at = "2026-01-01T00:00:00Z"
        self.folder_a.save(update_fields=["deleted_at"])

        self.client.force_login(self.user_a)
        response = self.client.post(
            reverse("share_folder", args=[self.folder_a.id]),
            {
                "username": self.user_b.username,
            },
        )
        self.assertEqual(response.status_code, 404)
        self.assertFalse(
            Share.objects.filter(
                folder=self.folder_a,
                receiver=self.user_b,
            ).exists()
        )
